odoo.define('library.fields', function (require) {
"use strict";

var basicFields = require('web.basic_fields');
var fieldRegistry = require('web.field_registry');

var RawFieldInteger = basicFields.FieldInteger.extend({
    /**
     * @override
     */
    _formatValue: function (value) {
        return value;
    },
});

var LateWidget = basicFields.FieldBoolean.extend({
    className: 'o_field_late_boolean',
    init: function () {
        this._super.apply(this, arguments);
        this.lateColor = this.nodeOptions.late_color || 'red';
        this.notLateColor = this.nodeOptions.not_late_color || 'green';
    },
    /**
     * @override
     * @private
     */
    _render: function () {
        this.$el.html($('<div>').css({
            backgroundColor: this.value ? this.lateColor : this.notLateColor
        }));
    },

});

fieldRegistry.add('raw-field-integer', RawFieldInteger);
fieldRegistry.add('late-boolean', LateWidget);

});